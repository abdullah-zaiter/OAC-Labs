Projeto do Processador MIPS v1.2

Para montar o projeto:
1) Abra o Quartus Prime v.17.1
2) Escolha Project/Restore Archieved Project
3) Escolha o arquivo Core.qar
4) Escolha o diretório de destino C:/.../MIPSv1.2/Core   (sem o _restored)
5) Pronto! :)

Lembre-se que no início do TopDE.v:
Escolha o Processador UNICICLO/MULTICILO/PIPELINE
Escolha se vai fazer SIMULACAO por forma de onda ou síntese na DE1-SoC (apenas deixe comentado o `define).
Para simulação em forma de onda use os arquivos Waveform1.vwf (mais curto) ou Waveform2.vwf (mais longo).

Bom trabalho!

Marcus Vinicius
2018/1